Running Tests
=============

To run the tests, execute the following from the project's root directory.

    $ make test

