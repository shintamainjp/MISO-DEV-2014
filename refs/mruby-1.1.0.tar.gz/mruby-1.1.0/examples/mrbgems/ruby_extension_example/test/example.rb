assert('Ruby Extension Example') do
  RubyExtension.respond_to? :ruby_method
end
