*****************************************************************************************


This ZIP File is associated with Rev 2 of the Application Note


    Blackfin� Processor and SDRAM Technology (EE-326)  


that can be found at http://www.analog.com/ee-notes.


Date Created:	December 11th, 2008


*****************************************************************************************


The archive provides several code examples:

Example 1 in directory EBIUSystemServices illustrates how to initialize the SDRAM with the System Services (ADSP-BF537) 

Example 2 in directory EBIUSystemServices BF561 illustrates how to initialize the SDRAM with the System Services (ADSP-BF561) (Project group)

Example 3 in directory InitSdramUsingAsm illustrateshow to initialize the SDRAM in assembly (ADSP-BF537)

Example 4 in directory InitSDRAMusingC illustrates how to initialize the SDRAM in C (ADSP-BF537)

Example 5 in directory InitSDRAMusingCBF561 illustrates how to initialize the SDRAM in C (ADSP-BF561)(Project group)

Example 6 in directory PerformanceExample illustrates how to do a high performance DMA transfer between two banks of the SDRAM(ADSP-BF561)

Example 7 in directory SettingIntoSelfRefresh illustrates the self refresh feature of the Blackfin 

Example 8 in directory UsingSections illustrates how to put code and data into sections

Example 9 in directory Init XML file for custom boards illustrates how to code a VDSP XML init file to set the SDRAM reset values (BF-537)  

*****************************************************************************************


All code examples have been written and tested with

	VisualDSP++ 5.0 Update 2 
	ADSP-BF561 EZ-KIT Lite board rev 1.3/2.1
	ADSP-BF561 silicon rev 0.3/0.5
	ADSP-BF537 EZ-KIT Lite board rev 2.1/2.2
	ADSP-BF537 silicon rev 0.2/0.3


*****************************************************************************************


