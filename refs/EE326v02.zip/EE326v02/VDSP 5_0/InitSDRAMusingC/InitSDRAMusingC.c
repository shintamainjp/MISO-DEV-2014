/*****************************************************************************
**																			**
**	 Name: 	Init SDRAM using C												**
**																			**
******************************************************************************

(C) Copyright 2006 - Analog Devices, Inc.  All rights reserved.

Project Name:	UART Example

Author: 		Fabian (DSP Application Engineer)

Version:		v1.1

Last Modified:	02/21/08

History:		v1.0 09/08/06
				v1.1 02/21/08

Software:		VisualDSP++ 5.0

Hardware:		ADSP-BF537 EZ-KIT Lite

Connections:	ADDS-HPUSB-ICE

Settings:		Switch off Settings->Target Options->Use XML reset values 		

Purpose:		To show how to initialize SDRAM by setting directly the registers

Comments:		The program will initialize the PLL settings and the SDRAM
				Afterwards it is requesting the Status of the SDRAM.
				
				At the output window you will see:
				Bus not granted 
	 			No error detected 
	 			Will power up on next SDRAM access  
	 			SDC is idle 
	 			SDRAM not in self refresh mode 
	 			SDC not in powerup sequence 
	 			
				Then an access to the SDRAM is processed and the status is
				requested again. 
				
				At the output window you will see:
				Bus not granted 
	 			No error detected 
	 			Will not power up on next SDRAM access / SDRAM already powered up
	 			SDC is idle 
	 			SDRAM not in self refresh mode 
	 			SDC not in powerup sequence 
				
*****************************************************************************/


/****************************************************************************
 Include Section
*****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <sys/exception.h>
#include <cdefBF537.h>
#include <ccblkfn.h>
#include <signal.h>

/****************************************************************************
 Program Define Section
*****************************************************************************/



/****************************************************************************
 Global Variables
*****************************************************************************/



/*****************************************************************************
 Function Prototype Section
******************************************************************************/
void SetPLL( void );
void SetSDRAM( void );
void StatusSDRAM( void );
/*****************************************************************************
 Interrupt Service Routines
******************************************************************************/



/****************************************************************************
 Main Program
*****************************************************************************/
int main()
{	int *pPointer;
    
    SetPLL(); 		//let's set the cclk 600 and the sclk 100; 
	SetSDRAM(); 	//Initialize the SDRAM
	printf("The status before accessing SDRAM \n");
	StatusSDRAM();	//Request SDRAM Status
	//An SDRAM access
	pPointer = 0x4; 		//set an address in the SDRAM
	*pPointer = 0xDEADBEEF; //write to the address
	printf("\n\n The status after accessing SDRAM \n");
	StatusSDRAM();	//Request SDRAM Status again
	while(1);
	return 0;
}

/****************************************************************************
 End of Main
*****************************************************************************/

/****************************************************************************
 Functions
*****************************************************************************/

void SetSDRAM(void) {

   
//SDRAM Refresh Rate Setting      
	*pEBIU_SDRRC = 0x307;

//SDRAM Memory Bank Control Register
	*pEBIU_SDBCTL =     EBCAW_10  | //Page size 1024 
						EBSZ_64   | //64 MB of SDRAM
						EBE; 		//SDRAM enable
	

//SDRAM Memory Global Control Register    					
	  *pEBIU_SDGCTL   = ~CDDBG 	& // Control disable during bus grant off
						~TCSR	& // Temperature compensated self-refresh off 
						~EMREN 	& // Extended mode register enabled off 
						~FBBRW	& // Fast back to back read to write off 	
						~EBUFE	& // External buffering enabled off
						~SRFS	& // Self-refresh setting off
						~PSM	& // Powerup sequence mode (PSM) first
						~PUPSD	& // Powerup start delay (PUPSD) off
				    	PSS		| // Powerup sequence start enable (PSSE) on
						TWR_2	| // Write to precharge delay TWR = 2 (14-15 ns)
						TRCD_2	| // RAS to CAS delay TRCD =2 (15-20ns)
						TRP_2	| // Bank precharge delay TRP = 2 (15-20ns)
						TRAS_4	| // Bank activate command delay TRAS = 4
						PASR_ALL| // Partial array self refresh
						CL_3	| // CAS latency
						SCTLE	; // SDRAM clock enable
						    					
    					    					
    					
} //End function SetSDRAM   
 

void StatusSDRAM( void ){
/* Bus Grant Status						*/
    if((*pEBIU_SDSTAT & BGSTAT)==BGSTAT)
    		{
    		    printf("\n Bus granted \n");
    		}
    else	  
  			{
  			    printf("\n Bus not granted \n");
  			};	

  			
/* SDRAM EAB Sticky Error Status		*/  		
    if((*pEBIU_SDSTAT & SDEASE)==SDEASE)
    		{
    		    printf(" EAB access generated an error \n");
    		}
    else	  
  			{
  			    printf(" No error detected \n");
  			};

/* SDRAM Will Power-Up On Next Access	*/  			
   	if((*pEBIU_SDSTAT & SDRS)==SDRS)
    		{
    		    printf(" Will power up on next SDRAM access  \n");
    		}
    else	  
  			{
  			    printf(" Will not power up on next SDRAM access / SDRAM already powered up\n");
  			};
  	
/* SDRAM Controller Idle 				*/  			
    if((*pEBIU_SDSTAT & SDCI)==SDCI)
    		{
    		    printf(" SDC is idle \n");
    		}
    else	  
  			{
  			    printf(" SDC is busy \n");
  			};
  			
/* SDRAM Self-Refresh Active			*/  				
  	if((*pEBIU_SDSTAT & SDSRA)==SDSRA)
    		{
    		    printf(" SDRAM in self refresh mode\n");
    		}
    else	  
  			{
  			    printf(" SDRAM not in self refresh mode \n");
  			};		
  			
  								 
 /* SDRAM Power-Up Active 				*/   
  	if((*pEBIU_SDSTAT & SDPUA)==SDPUA)
    		{
    		    printf(" SDC in powerup sequence \n");
    		}
    else	  
  			{
  			    printf(" SDC not in powerup sequence \n");
  			};			
}       

void SetPLL(void) {
  //Sets the PLL 

  //var Definition
  unsigned int IntMask;

  //Ensure no other interrupt will disturb us
  IntMask = cli();

    //Setup the DIV of ssclk and cclk
  *pPLL_DIV = 0x0006;

  //Setup wait cycles until PLL is set
  *pPLL_LOCKCNT = 0x200;

  //Setup the PLL
  //*pPLL_CTL = 0x3000;
  *pVR_CTL = 0x40DB;

  //Wait the PLL settings are done
  idle();

  //restore interrupts
  sti(IntMask);

} //End function SetPLL			


/****************************************************************************
 End of Functions
*****************************************************************************/
	

/****************************************************************************
 end of The program
*****************************************************************************/



