#include <cdefBf561.h>
#include <ccblkfn.h>

void main()
{
// Insert asm because VDSP is setting a breakpoint to the first line
asm("nop;"); 
while(1)
{
    idle();
};
 while(1); // we will never come here  
}
