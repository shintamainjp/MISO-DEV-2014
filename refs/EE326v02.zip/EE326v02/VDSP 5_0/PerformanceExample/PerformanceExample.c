/*****************************************************************************
**																			**
**	 Name: 	Performance Example																**
**																			**
******************************************************************************

(C) Copyright 2006 - Analog Devices, Inc.  All rights reserved.

Project Name:	

Author: 		Fabian (DSP Application Engineer)

Version:		v1.0

Last Modified:	09/19/06

History:		v1.0 09/19/06

Software:		VisualDSP++ 5.0

Hardware:		ADSP-BF537 EZ-KIT Lite

Connections:	ADDS-HPUSB-ICE

Settings:		None		

Purpose:		To show how to organize a MDMA transfer
				The program draws a picture by using the DMAs 
				The "pencil" is placed in bank 2 and the picture will 
				be drawn in bank 3. 
				BANK2_PAGE1 ---DMA Transfer ---> BANK3_PAGE1

Comments:		Imagine we would use the same bank for the pencil and for the 
				picture:
				First the source DMA has to get its colour, so it is accessing 
				the page where it is placed.Therefore the SDRAM has to close
				the page and have to open the page where the pencil is placed.
				Afterwards the destination DMA has to write the colour into the
				picture. Therefore it has to close the page and have to open the
				picture page. Since opening and closing is very time consuming,
				we spend a lot of time in these procedures. 
				We can prevent the time consuming procedure by placing the palette 
				and the picture	in two different banks.
				
				To do this test: 
				Open View->Debug Windows->ImageViewer
				Set the Start Address to MyArray
				Pixelformat: Grayscale (8bit)
				width and height 20 pixels
				
				Run The program
				Stop the program and press the update buttom of the Image Viewer 
				   


*****************************************************************************/


/****************************************************************************
 Include Section
*****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <sys/exception.h>
#include <cdefBF537.h>
#include <ccblkfn.h>
#include <signal.h>

/****************************************************************************
 Program Define Section
*****************************************************************************/

/****************************************************************************
 Type Definitions
*****************************************************************************/
typedef struct DESCRIPTOR_SMALL { 			            			// DMA descriptor small model
    unsigned short                  		   	pNext;              // next descriptor in the chain
    unsigned short                             	StartAddressLow;    // lower 16 bits of the start address of the data
    unsigned short                             	StartAddressHigh;   // upper 16 bits of the start address of the data
    unsigned short              				Config;             // configuration control register
    unsigned short                             	XCount;             // X (column) count
    signed short                             	XModify;            // X (column) stride
    unsigned short                             	YCount;             // Y (row) count
    signed short                             	YModify;            // Y (row) stride
} DESCRIPTOR_SMALL;

/****************************************************************************
 Global Variables
*****************************************************************************/
section ("sdram2page1") char Pencils[400]; //an array within a page
section ("sdram3page1") char MyArray[400]; //an array within a page
section ("sdram0page1") struct DESCRIPTOR_SMALL Descriptor[20];
/*****************************************************************************
 Function Prototype Section
******************************************************************************/
void SetUpDMAs( void );
void SetUpArray( void );
/*****************************************************************************
 Interrupt Service Routines
******************************************************************************/



/****************************************************************************
 Main Program
*****************************************************************************/
int main()
{
    SetUpArray();
    SetUpDMAs();
    
    while(1);
	return 0;
}

/****************************************************************************
 End of Main
*****************************************************************************/

/****************************************************************************
 Functions
*****************************************************************************/
void SetUpDMAs( void )
{
 //Discriptor 0 : First Line (high left to low right)
 Descriptor[0].pNext = (unsigned short)(((int)(&Descriptor[1]))&(0xffff));              
 Descriptor[0].StartAddressLow=(unsigned short)(((unsigned int)(&MyArray[0])&(0xffff)));    
 Descriptor[0].StartAddressHigh=(unsigned short)((((unsigned int)(&MyArray[0])&(0xffff0000)))>>16);;   
 Descriptor[0].Config= FLOW_SMALL|NDSIZE_8|WNR|WDSIZE_8|DMAEN;             
 Descriptor[0].XCount=20;             
 Descriptor[0].XModify=21;            
 Descriptor[0].YCount=0;             
 Descriptor[0].YModify=0;	   
 //Discriptor 1 : Second Line (high right to low left)
 Descriptor[1].pNext = (unsigned short)(((int)(&Descriptor[2]))&(0xffff));              
 Descriptor[1].StartAddressLow=(unsigned short)(((int)(&MyArray[19])&(0xffff)));    
 Descriptor[1].StartAddressHigh=(unsigned short)((((int)(&MyArray[19])&(0xffff0000)))>>16);   
 Descriptor[1].Config= FLOW_SMALL|NDSIZE_8|DI_EN|WNR|WDSIZE_8|DMAEN;             
 Descriptor[1].XCount=20;             
 Descriptor[1].XModify=19;            
 Descriptor[1].YCount=0;             
 Descriptor[1].YModify=0;
 // Insert your own command ;)
 Descriptor[2].pNext = (unsigned short)(((int)(&Descriptor[2]))&(0xffff));              
 Descriptor[2].StartAddressLow=(unsigned short)(((int)(&MyArray[20])&(0xffff)));    
 Descriptor[2].StartAddressHigh=(unsigned short)((((int)(&MyArray[20])&(0xffff0000))))>>16;   
 Descriptor[2].Config= 0;             
 Descriptor[2].XCount=0;             
 Descriptor[2].XModify=0;            
 Descriptor[2].YCount=0;             
 Descriptor[2].YModify=0;
 *pMDMA_D0_CURR_DESC_PTR= &Descriptor;
 *pMDMA_D0_NEXT_DESC_PTR= &Descriptor;
 *pMDMA_D0_X_COUNT = 1000;
 *pMDMA_D0_X_MODIFY = 0;
 //setup the Source DMA
 *pMDMA_S0_START_ADDR = &Pencils[210];
 *pMDMA_S0_X_COUNT = 40;
 *pMDMA_S0_X_MODIFY = 1;
 *pMDMA_S0_CONFIG = FLOW_AUTO|WDSIZE_8|DMAEN; 
 ssync();
 *pMDMA_D0_CONFIG = FLOW_SMALL|NDSIZE_8|DMAEN;
}
/*---------------------------------------------------------------------------
			Function:  SetUpArray ( void )
			Purpose:   To set up a pencil to draw

----------------------------------------------------------------------------*/
void SetUpArray( void )
{
   int i;
     
 	Pencils[0]= 0; // white
    for (i=1;i<255;i++)
    {
        Pencils[i] = Pencils[i-1]+1;
    }    
    
       
}    
/****************************************************************************
 End of Functions
*****************************************************************************/
	

/****************************************************************************
 end of The program
*****************************************************************************/



