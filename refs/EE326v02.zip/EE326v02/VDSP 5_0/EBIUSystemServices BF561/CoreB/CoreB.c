#include <cdefBf561.h>
#include <ccblkfn.h>

void main()
{
    //Insert a nop at the beginning of the programm because VDSP is placing here a breakpoint
    asm("nop;"); 
    while(1)
    {
        idle();
    };
    while(1); // we will never come here  
}
